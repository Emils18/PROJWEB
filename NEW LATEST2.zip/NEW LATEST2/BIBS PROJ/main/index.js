document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

/* Please don't touch this or rename this file if you don't have idea about it */

// THIS AREA CHANGE PHOTO OF CARD 1 in OUR SERVICE How to change?
// You can see  img.src = 'images/power.png'; "images" is the file location make sure to save the photo in that file.
//and the "power.png" is the name of the saved photo so it means the location of the file image make sure to save it propertly when you download
document.getElementById('t1').addEventListener('change', () => {
const img = document.getElementById('icon-card1');
const selector = document.getElementById('t1').value;
const info = document.getElementById('info1');
switch(selector){
    case 'o1':
        img.src = 'images/power.png';
        info.textContent = " a branch of physics that deals with the giving off, action, and effects of electrons and with electronic devices. ";
        break;
    case 'o2':
        img.src = 'images/subnation.png';
        break;
    case 'o3':
        img.src = 'images/motor.png';
        break;
    case 'o4':
        img.src = 'images/auto.png';
        break;
    case 'o5':
            img.src = 'images/capacitor.png';
            break;
    case 'o6':
            img.src = 'images/distribution.png';
                break;
    case 'o7':
            img.src = 'images/generator.png';
            break;
    case 'o8':
         img.src = 'images/maintenance.png';
        break;        
    }
});

// THIS AREA CHANGE PHOTO OF CARD 2 in OUR SERVICE How to change?
// You can see  img.src = 'images/pipe.png'; "images" is the file location make sure to save the photo in that file.
//and the "pipe.png" is the name of the saved photo so it means the location of the file image make sure to save it propertly when you download
document.getElementById('t2').addEventListener('change', () => {
const img = document.getElementById('icon-card2');
const t2 = document.getElementById('t2').value;
const info = document.getElementById('info2');

switch(t2){
    case 'o1':
        img.src = 'images/pipe.png';
        info.textContent = " a branch of physics that deals with the giving off, action, and effects of electrons and with electronic devices. ";
        break;
    case 'o2':
        img.src = 'images/subnation.png';
        break;
    case 'o3':
        img.src = 'images/motor.png';
        break;
    case 'o4':
        img.src = 'images/auto.png';
        break;
    case 'o5':
            img.src = 'images/capacitor.png';
            break;
    case 'o6':
            img.src = 'images/distribution.png';
                break;
    case 'o7':
            img.src = 'images/generator.png';
            break;
    case 'o8':
         img.src = 'images/maintenance.png';
        break;        
    }

});
// THIS AREA CHANGE PHOTO OF CARD 3 in OUR SERVICE How to change?
// You can see  img.src = 'images/pipe.png'; "images" is the file location make sure to save the photo in that file.
//and the "pipe.png" is the name of the saved photo so it means the location of the file image make sure to save it propertly when you download
document.getElementById('t3').addEventListener('change', () => {
    const img = document.getElementById('icon-card3');
    const t2 = document.getElementById('t3').value;
    const info = document.getElementById('info3');
    
    switch(t2){
        case 'o1':
            img.src = 'images/pipe.png';
            info.textContent = " a branch of physics that deals with the giving off, action, and effects of electrons and with electronic devices. ";
            break;
        case 'o2':
            img.src = 'images/subnation.png';
            break;
        case 'o3':
            img.src = 'images/motor.png';
            break;
        case 'o4':
            img.src = 'images/auto.png';
            break;
        case 'o5':
                img.src = 'images/capacitor.png'; // BASTA SUNOD RANI SILA TANAN TOL
                break;
        case 'o6':
                img.src = 'images/distribution.png'; //ENCLOSED CONTROL STARTERS
                    break;
        case 'o7':
                img.src = 'images/generator.png'; // S/S & MS PLATE CABLE TRAY, WIRE GUTTERS, METAL ENCLOSURE
                break;       
        }
    
    });

    // for confirmation form
    
    document.getElementById("contactForm").addEventListener("submit", function(event) {
        event.preventDefault();

        const form = this;
        const confirmationMessage = document.getElementById("confirmationMessage");
       

       
        const formData = new FormData(form);

       
        fetch(form.action, {
            method: form.method,
            body: formData
        })
        .then(response => {
            if (response.ok) {

                confirmationMessage.classList.add("show");
                
                form.reset();

                setTimeout(() => {
                    confirmationMessage.classList.remove("show");
                    confirmationMessage.classList.add("hide");
                    window.location.href = "http://127.0.0.1:5500/BIBS%20PROJ/main/index.html"; 
                }, 5000); 
               
            } else {
                
                alert("Something went wrong. Please try again.");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Something went wrong. Please try again.");
        });
    });